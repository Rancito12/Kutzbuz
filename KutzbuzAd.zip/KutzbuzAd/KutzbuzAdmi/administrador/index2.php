<?php
require_once('bd/Conexion.php');
require_once('Controlador/Recarga_Controller.php');

$controller = new Recarga_Controller();

if (!empty($_REQUEST['m'])) {
    $metodo = $_REQUEST['m'];
    if (method_exists($controller, $metodo)) {
        $controller->$metodo();
    } else {
        
        $controller->index();
    }
} else {

    $controller->index();
}
?>

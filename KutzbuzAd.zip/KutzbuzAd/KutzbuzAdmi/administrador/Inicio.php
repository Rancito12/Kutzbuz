<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manual de Recargas</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f4f4f4;
        }
        .wrapper {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            background-color: #e0e0e0;
            color: #333;
            width: 250px;
            padding-top: 20px;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar-logo img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
        }
        .sidebar-nav {
            list-style-type: none;
            padding-left: 0;
        }
        .sidebar-nav-item {
            padding: 10px 20px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
        .sidebar-nav-item a {
            color: #333;
            text-decoration: none;
        }
        .sidebar-nav-item a:hover {
            text-decoration: none;
            color: #555;
        }
        .main-panel {
            flex: 1;
            padding: 30px;
        }
        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #467298;
        }
        .pdf-container {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .pdf-viewer {
            width: 100%;
            height: 600px;
        }
        .footer {
            background-color: #467298;
            color: #fff;
            padding: 20px 0;
            text-align: center;
            margin-top: auto;
        }
        .footer a {
            color: #fff;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        /* Estilos adicionales para íconos más grandes */
        .icon-big {
            font-size: 48px; /* Tamaño de fuente más grande */
            line-height: 1; /* Alineación vertical */
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="img/LOGOKUTZ.png" alt="Logo">
            </div>
            <ul class="sidebar-nav">
                <li class="sidebar-nav-item">
                    <a href="./Inicio.php">
                        <i class="fas fa-home"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="./Recarga_Agregar.php">
                        <i class="fas fa-gem"></i>
                        <span>Nueva Recarga</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="./Empleado.php">
                        <i class="fas fa-user-plus"></i>
                        <span>Nuevo Empleado</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="./index2.php">
                        <i class="fas fa-bell"></i>
                        <span>Recargas</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="./index.php">
                        <i class="fas fa-users"></i>
                        <span>Empleados</span>
                    </a>
                </li>
                <li class="sidebar-nav-item active">
                    <a href="./ManualRecar.php">
                        <i class="fas fa-book"></i>
                        <span>Manual de Recarga</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="https://wa.me/9995163469">
                        <i class="fas fa-question-circle"></i>
                        <span>Ayuda</span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="main-panel">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#">INICIO</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i> Cuenta
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="cerrar.php">Cerrar sesión</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
         
            <?php
// Configuración de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "administrador";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("La conexión ha fallado: " . $conn->connect_error);
}

// Obtener el total de recargas y el número de empleados
$sql_total_recargas = "SELECT SUM(monto) as total_recargas FROM recargas";
$result_total_recargas = $conn->query($sql_total_recargas);

if ($result_total_recargas === false) {
    die("Error en la consulta: " . $conn->error);
}

if ($result_total_recargas->num_rows > 0) {
    $row = $result_total_recargas->fetch_assoc();
    $total_recargas = $row['total_recargas'];
} else {
    $total_recargas = 0;
}

// Obtener la suma de recargas por empleado
$sql_recargas_empleado = "SELECT Id_Empleado, SUM(Monto) as total_recargas FROM recargas GROUP BY Id_Empleado";
$result_recargas_empleado = $conn->query($sql_recargas_empleado);

$datos_empleados = [];

if ($result_recargas_empleado->num_rows > 0) {
    while ($row = $result_recargas_empleado->fetch_assoc()) {
        $datos_empleados[] = $row;
    }
}

// Calcular el promedio mensual
$sql_total_recargas_all = "SELECT SUM(Monto) as total_recargas FROM recargas";
$result_total_recargas_all = $conn->query($sql_total_recargas_all);

if ($result_total_recargas_all === false) {
    die("Error en la consulta: " . $conn->error);
}

if ($result_total_recargas_all->num_rows > 0) {
    $row = $result_total_recargas_all->fetch_assoc();
    $total_recargas_all = $row['total_recargas'];
} else {
    $total_recargas_all = 0;
}

$sql_empleados = "SELECT COUNT(*) as total_empleados FROM empleados";
$result_empleados = $conn->query($sql_empleados);

if ($result_empleados === false) {
    die("Error en la consulta: " . $conn->error);
}

if ($result_empleados->num_rows > 0) {
    $row = $result_empleados->fetch_assoc();
    $total_empleados = $row['total_empleados'];
} else {
    $total_empleados = 0;
}

// Calcular el promedio mensual
if ($total_empleados > 0) {
    $promedio_mensual = $total_recargas_all / $total_empleados;
} else {
    $promedio_mensual = 0;
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gráfica de Recargas por Empleado</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="mat.css">
</head>
<body>
    <div class="chart-container">
        <canvas id="recargasLineChart" width="600" height="400"></canvas>
    </div>
    <script>
        const datosEmpleados = <?php echo json_encode($datos_empleados); ?>;
        const promedioMensual = <?php echo $promedio_mensual; ?>;
        
        // Preparar los datos para la gráfica
        const labels = datosEmpleados.map(item => `Empleado ${item.Id_Empleado}`);
        const data = datosEmpleados.map(item => item.total_recargas);
        const promedioData = new Array(labels.length).fill(promedioMensual);

        const ctxLine = document.getElementById('recargasLineChart').getContext('2d');

        const recargasLineChart = new Chart(ctxLine, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Recargas por Empleado',
                        data: data,
                        borderColor: 'rgba(0, 0, 255, 1)', // Azul
                        backgroundColor: 'rgba(0, 0, 255, 0.2)', // Azul claro para el área
                        borderWidth: 2,
                        fill: true, // Rellenar el área bajo la línea
                        pointBackgroundColor: 'rgba(0, 0, 255, 1)', // Color de los puntos
                        pointRadius: 5 // Radio de los puntos
                    },
                    {
                        label: 'Promedio Mensual',
                        data: promedioData,
                        borderColor: 'rgba(255, 0, 0, 1)', // Rojo
                        borderWidth: 2,
                        fill: false, // No rellenar el área bajo la línea
                        borderDash: [10, 5] // Línea punteada
                    }
                ]
            },
            options: {
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Empleado'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Monto Total'
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>


            
    <footer class="footer mt-auto py-3">
        <div class="container text-center">
            <span class="text-white">© <script>document.write(new Date().getFullYear())</script>, hecho con <i
                    class="fa fa-heart"></i> por el equipo de KUTZBUZ</span>
        </div>
    </footer>

</html>

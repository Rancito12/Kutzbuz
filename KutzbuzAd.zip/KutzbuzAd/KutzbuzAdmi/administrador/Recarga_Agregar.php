<?php
require_once('Bd/Conexion.php');
require_once('Controlador/Recarg_Controller.php');

$controller = new Recarg_Controller();

if (!empty($_REQUEST['m'])) {
    $metodo = $_REQUEST['m'];
    if (method_exists($controller, $metodo)) {
        $controller->$metodo();
    } else {
      
        $controller->create();
    }
} else {
    
    $controller->index();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manual de Recargas</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f4f4f4;
        }
        .wrapper {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            background-color: #e0e0e0;
            color:#333;
            width: 250px;
            padding-top: 20px;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar-logo img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
        }
        .sidebar-nav {
            list-style-type: none;
            padding-left: 0;
        }
        .sidebar-nav-item {
            padding: 10px 20px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
        .sidebar-nav-item a {
            color: #333;
            text-decoration: none;
        }
        .sidebar-nav-item a:hover {
            text-decoration: none;
            color: #555;
        }
        .main-panel {
            flex: 1;
            padding: 30px;
        }
        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #467298;
        }
        .pdf-container {
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .pdf-viewer {
            width: 100%;
            height: 600px;
        }
        .footer {
            background-color: #467298;
            color: #fff;
            padding: 20px 0;
            text-align: center;
            margin-top: auto;
        }
        .footer a {
            color: #fff;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="img/LOGOKUTZ.png" alt="Logo">
            </div>
            <ul class="sidebar-nav">
                <li class="sidebar-nav-item">
                    <a href="./Inicio.php">
                        <i class="fas fa-home"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="./Recarga_Agregar.php">
                        <i class="fas fa-gem"></i>
                        <span>Nueva Recarga</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="./Empleado_Agregar.php">
                        <i class="fas fa-user-plus"></i>
                        <span>Nuevo Empleado</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="./index2.php">
                        <i class="fas fa-bell"></i>
                        <span>Recargas</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="./index.php">
                        <i class="fas fa-users"></i>
                        <span>Empleados</span>
                    </a>
                </li>
                <li class="sidebar-nav-item active">
                    <a href="./ManualRecar.php">
                        <i class="fas fa-book"></i>
                        <span>Manual de Recarga</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href=" https://wa.me/9995163469">
                        <i class="fas fa-question-circle"></i>
                        <span>Ayuda</span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="main-panel">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="#">Manual de Recargas</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i> Cuenta
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="../cerrar.php">Cerrar sesión</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="container">
                <div class="pdf-container">
                    <?php
                    // Define the path to your PDF file
                    $filePath = 'PDF/MANUAL DE RECARGA.pdf';
                    echo '<embed class="pdf-viewer" src="' . htmlspecialchars($filePath) . '" type="application/pdf" />';
                    ?>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

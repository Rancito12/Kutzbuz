<?php
// Empleado_Controller.php
require_once('Modelo/Emplea_model.php');

class Emplea_Controller {
    private $model;

    function __construct(){
        $this->model = new Emplea_model();
    }

    function index(){
        $empleados = $this->model->get();
        include_once('vista/header.php');
        include_once('vista/CatalogoEmpleado.php'); 
        include_once('vista/footer.php');
    }

    function create(){
        include_once('vista/header.php');
        include_once('vista/Empleado.php'); 
        include_once('vista/footer.php');
    }

    function store(){
        $data = $this->getDataFromPost();

        
        if (isset($_FILES['NuevaFoto']) && $_FILES['NuevaFoto']['name'] !== '') {
            $rutaFoto = $this->guardarFoto();
            $data['Foto'] = $rutaFoto;
        } else {
            
            $data['Foto'] = 'img/default.jpg'; 
        }

        // Insertar 
        $this->model->insert($data);

        
        header('Location: index.php');
        exit();
    }

    function edit($id){
        $empleado = $this->model->find($id); 
        if (!$empleado) {
            
            die('Empleado no encontrado');
        }
        include_once('vista/header.php');
        include_once('vista/Empleado.php'); 
        include_once('vista/footer.php');
    }

    function update($id){
        $data = $this->getDataFromPost();

        
        if (isset($_FILES['NuevaFoto']) && $_FILES['NuevaFoto']['name'] !== '') {
            $rutaFoto = $this->guardarFoto();
            $data['Foto'] = $rutaFoto;
        }

        
        $this->model->update($id, $data);

        
        header('Location: index.php');
        exit();
    }

    function destroy($id){
        
        $this->model->delete($id);

        
        header('Location: index.php');
        exit();
    }

    private function getDataFromPost() {
        return [
            'Nombre' => $_POST['Nombre'],
            'ApellidoPater' => $_POST['ApellidoPater'],
            'ApellidoMat' => $_POST['ApellidoMat'],
            'Telefono' => $_POST['Telefono'],
            'Fecha_Registro' => $_POST['Fecha_Registro'], 
            'Contraseña' => $_POST['Contraseña'],
            'ConfContra' => $_POST['ConfContra'],
            'Foto' => isset($_POST['Foto']) ? $_POST['Foto'] : '', // Verificar 
        ];
    }

    private function guardarFoto() {
        $directorioSubida = 'img/'; // Ruta donde esta la foto
        $nombreArchivo = $_FILES['NuevaFoto']['name'];
        $rutaCompleta = $directorioSubida . $nombreArchivo;

        if (move_uploaded_file($_FILES['NuevaFoto']['tmp_name'], $rutaCompleta)) {
            return $rutaCompleta;
        } else {
            //error al subir la foto
            die('Error al subir la foto');
        }
    }
}

// uso del controlador
$action = isset($_GET['action']) ? $_GET['action'] : 'index';
$controller = new Emplea_Controller();

switch ($action) {
    case 'index':
        $controller->index();
        break;
    case 'create':
        $controller->create();
        break;
    case 'store':
        $controller->store();
        break;
    case 'edit':
        $id = isset($_GET['Id_Empleado']) ? $_GET['Id_Empleado'] : null;
        if (!$id) {
            // Manejar el caso donde no se proporciona ID válido
            die('ID de empleado no proporcionado');
        }
        $controller->edit($id);
        break;
    case 'update':
        $id = isset($_GET['Id_Empleado']) ? $_GET['Id_Empleado'] : null;
        if (!$id) {
           
            die('ID de empleado no proporcionado');
        }
        $controller->update($id);
        break;
    case 'destroy':
        $id = isset($_GET['Id_Empleado']) ? $_GET['Id_Empleado'] : null;
        if (!$id) {
            
            die('ID de empleado no proporcionado');
        }
        $controller->destroy($id);
        break;
    default:
        // Manejar el caso donde la acción no es válida
        die('Acción no válida');
}
?>

<?php
require_once('Modelo/Recarga_model.php');

class Recarga_Controller {
    private $model_r;

    function __construct(){
        $this->model_r = new Recarga_model();
    }

    function index(){
        // Obtener todas las recargas
        $recargas = $this->model_r->get();

        // Incluir el encabezado de la vista
        include_once('vista/header.php');

        // Incluir la vista de recargas con los datos obtenidos
        include_once('vista/CatalogoRecarga.php');

        // Incluir el pie de página de la vista
        include_once('vista/footer.php');
    }
}

// Ejemplo de uso del controlador
$controller = new Recarga_Controller();
$controller->index();
?>


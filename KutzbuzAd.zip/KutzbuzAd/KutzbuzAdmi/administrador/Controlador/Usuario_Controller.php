<?php
// Usuario_Controller.php
require_once('Modelo/Usuario_model.php');

class Usuario_Controller {
    private $model;

    function __construct(){
        $this->model = new Usuario_model();
    }

    function index(){
        $empleados = $this->model->get();
        include_once('vista/header.php');
        include_once('vista/EmpleadoAgre.php'); // Vista de listado de empleados
        include_once('vista/footer.php');
    }

    function create(){
        include_once('vista/header.php');
        include_once('vista/Empleado.php'); // Vista de formulario de creación
        include_once('vista/footer.php');
    }

    function store(){
        $data = $this->getDataFromPost();

        // Insertar empleado en la base de datos
        $this->model->insert($data);

        // Redireccionar al listado de empleados
        header('Location: index.php');
        exit();
    }

    private function getDataFromPost() {
        $data = [
            'Nombre' => isset($_POST['Nombre']) ? $_POST['Nombre'] : '',
            'ApellidoPater' => isset($_POST['ApellidoPater']) ? $_POST['ApellidoPater'] : '',
            'ApellidoMat' => isset($_POST['ApellidoMat']) ? $_POST['ApellidoMat'] : '',
            'Telefono' => isset($_POST['Telefono']) ? $_POST['Telefono'] : '',
            'Fecha_Registro' => isset($_POST['Fecha_Registro']) ? $_POST['Fecha_Registro'] : '',
            'Contraseña' => isset($_POST['Contraseña']) ? $_POST['Contraseña'] : '',
            'ConfContra' => isset($_POST['ConfContra']) ? $_POST['ConfContra'] : '',
            'Foto' => '' // Valor por defecto para 'Foto'
        ];

        // Verificar si se ha subido una nueva foto
        if (isset($_FILES['NuevaFoto']['name']) && $_FILES['NuevaFoto']['name'] !== '') {
            $data['Foto'] = $this->guardarFoto(); // Llama al método para guardar la foto
        }

        return $data;
    }

    private function guardarFoto() {
        $directorioSubida = 'img/'; // Ruta donde se almacenará la foto
        $nombreArchivo = $_FILES['NuevaFoto']['name'];
        $rutaCompleta = $directorioSubida . $nombreArchivo;

        if (move_uploaded_file($_FILES['NuevaFoto']['tmp_name'], $rutaCompleta)) {
            return $rutaCompleta;
        } else {
            // Manejar el caso de error al subir la foto
            die('Error al subir la foto');
        }
    }
}

// Ejemplo de uso del controlador
$action = isset($_GET['action']) ? $_GET['action'] : 'index';
$controller = new Usuario_Controller();

switch ($action) {
    case 'index':
        $controller->index();
        break;
    case 'create':
        $controller->create();
        break;
    case 'store':
        $controller->store();
        break;
    default:
        // Manejar el caso donde la acción no es válida
        // Podrías redirigir a una página de error o mostrar un mensaje de error
        die('Acción no válida');
}
?>

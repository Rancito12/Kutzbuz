<?php
require_once('Modelo/Recarg_model.php');

class Recarg_Controller {
    private $model_r;

    function __construct(){
        $this->model_r = new Recarg_model();
    }

    function index(){
        // Obtener todas las recargas
        $recargas = $this->model_r->get();

        // Incluir el encabezado de la vista
        include_once('vista/header.php');

        // Incluir la vista de recargas con los datos obtenidos
        include_once('vista/Recarga.php');

        // Incluir el pie de página de la vista
        include_once('vista/footer.php');
    }

    function agregar($tarjeta, $monto, $fechaRegistro, $idEmpleado){
        // Aquí puedes realizar la lógica para agregar una nueva recarga
        $datos = [
            'Tarjeta' => $tarjeta,
            'Monto' => $monto,
            'Fecha_Registro' => $fechaRegistro,
            'Id_Empleado' => $idEmpleado
        ];

        $exito = $this->model_r->agregar($datos);

        if ($exito) {
            // Redireccionar a la página principal u otra página de éxito
            header('Location: Recarga_Agregar.php');
            exit;
        } else {
            // Manejar el caso de error, por ejemplo, mostrar un mensaje de error
            echo "Error al agregar la recarga.";
        }
    }
}

// Ejemplo de uso del controlador
$controller = new Recarg_Controller();

// Verificar si se está enviando el formulario para agregar una recarga
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['Tarjeta']) && isset($_POST['Monto']) && isset($_POST['Id_Empleado'])) {
    // Validar y obtener los datos del formulario
    $tarjeta = $_POST['Tarjeta']; // Asegúrate de validar y limpiar los datos
    $monto = $_POST['Monto']; // Asegúrate de validar y limpiar los datos
    $fechaRegistro = $_POST['Fecha_Registro']; // La fecha viene del formulario
    $idEmpleado = $_POST['Id_Empleado']; // Asegúrate de validar y limpiar los datos

    // Llamar al método agregar del controlador
    $controller->agregar($tarjeta, $monto, $fechaRegistro, $idEmpleado);
} else {
    // Si no es un POST, simplemente muestra la página principal
    // También podrías pasar la fecha actual al formulario en este punto si es necesario
    $fecha_actual = date('Y-m-d'); // Obtener fecha actual
    $controller->index();
}
?>
<?php
// Empleado_model.php

require_once('bd/Conexion.php'); 
class Usuario_model {
    private $DB;

    function __construct(){
        $this->DB = Database::connect();
    }

    function get(){
        
        $sql = 'SELECT * FROM empleados';
        $stmt = $this->DB->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function insert($data){
       
        $sql = "INSERT INTO empleados (Nombre, ApellidoPater, ApellidoMat, Telefono, Fecha_Registro, Contraseña, ConfContra, Foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->DB->prepare($sql);
        $stmt->execute([$data['Nombre'], $data['ApellidoPater'], $data['ApellidoMat'], $data['Telefono'], $data['Fecha_Registro'], $data['Contraseña'], $data['ConfContra'], $data['Foto']]);
    }
}
?>

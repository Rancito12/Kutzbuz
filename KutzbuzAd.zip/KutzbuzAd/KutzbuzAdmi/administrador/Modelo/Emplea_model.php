<?php
// Emplea_model.php

require_once('bd/Conexion.php'); 

class Emplea_model {
    private $DB;

    function __construct(){
        $this->DB = Database::connect(); 
    }

    function get(){
        try {
            // Obtener todos los empleados
            $sql = 'SELECT * FROM empleados';
            $stmt = $this->DB->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die('Error al obtener empleados: ' . $e->getMessage());
        }
    }

    function find($id){
        try {
            // Obtener un empleado por ID
            $sql = "SELECT * FROM empleados WHERE Id_Empleado = ?";
            $stmt = $this->DB->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die('Error al obtener empleado por ID: ' . $e->getMessage());
        }
    }

    function insert($data){
        try {
            // Insertar empleado
            $sql = "INSERT INTO empleados (Nombre, ApellidoPater, ApellidoMat, Telefono, Fecha_Registro, Contraseña, ConfContra, Foto) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $this->DB->prepare($sql);
            $stmt->execute([$data['Nombre'], $data['ApellidoPater'], $data['ApellidoMat'], $data['Telefono'], $data['Fecha_Registro'], $data['Contraseña'], $data['ConfContra'], $data['Foto']]);
        } catch (PDOException $e) {
            die('Error al insertar empleado: ' . $e->getMessage());
        }
    }

    function update($id, $data){
        try {
            // Actualizar empleado
            $sql = "UPDATE empleados SET Nombre = ?, ApellidoPater = ?, ApellidoMat = ?, Telefono = ?, Fecha_Registro = ?, Contraseña = ?, ConfContra = ?, Foto = ? WHERE Id_Empleado = ?";
            $stmt = $this->DB->prepare($sql);
            $stmt->execute([$data['Nombre'], $data['ApellidoPater'], $data['ApellidoMat'], $data['Telefono'], $data['Fecha_Registro'], $data['Contraseña'], $data['ConfContra'], $data['Foto'], $id]);
        } catch (PDOException $e) {
            die('Error al actualizar empleado: ' . $e->getMessage());
        }
    }

    function delete($id){
        try {
            // Eliminar empleado
            $sql = "DELETE FROM empleados WHERE Id_Empleado = ?";
            $stmt = $this->DB->prepare($sql);
            $stmt->execute([$id]);
        } catch (PDOException $e) {
            die('Error al eliminar empleado: ' . $e->getMessage());
        }
    }
}
?>

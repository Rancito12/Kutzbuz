<?php
require_once('Bd/Conexion.php'); 

class Recarg_model {
    private $db; 
    function __construct(){
        $this->db = Database::connect(); 
    }

    function agregar($datos){
        // Insertar datos en la tabla de recargas
        try {
            $sql = "INSERT INTO recargas (Tarjeta, Monto, Fecha_Registro, Id_Empleado) VALUES (?, ?, ?, ?)";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$datos['Tarjeta'], $datos['Monto'], $datos['Fecha_Registro'], $datos['Id_Empleado']]);
            return true; // Inserción exitosa
        } catch (PDOException $e) {
            // Para error de inserción 
            return false;
        }
    }

    function get(){
        // Llamar todas las recargas
        try {
            $sql = "SELECT * FROM recargas";
            $stmt = $this->db->query($sql);
            $recargas = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $recargas;
        } catch (PDOException $e) {
            // Para error de consulta 
            return [];
        }
    }
}
?>

    
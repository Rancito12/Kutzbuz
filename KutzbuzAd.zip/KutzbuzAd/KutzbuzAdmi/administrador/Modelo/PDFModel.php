<?php

// app/models/PDFModel.php

class PDFModel {
    
    public static function getPdfPath() {
        return './PDF/ManualRecargas.pdf'; 
    }

}
?>

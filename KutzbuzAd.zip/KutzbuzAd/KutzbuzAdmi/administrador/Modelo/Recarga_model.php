<?php
    
class Recarga_model {
    private $DB;

    function __construct(){
        $this->DB = Database::connect(); 
    }

    function get(){
        // Llamar todas las recargas ordenadas por Id_Recarga descendente
        $sql = 'SELECT * FROM recargas ORDER BY Id_Recarga DESC';
        $stmt = $this->DB->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getByDay($fecha){
        
        $sql = "SELECT * FROM recargas WHERE DATE(Fecha_Registro) = ?";
        $stmt = $this->DB->prepare($sql);
        $stmt->execute([$fecha]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getByMonth($fecha){
        
        $sql = "SELECT * FROM recargas WHERE MONTH(Fecha_Registro) = MONTH(?) AND YEAR(Fecha_Hora) = YEAR(?)";
        $stmt = $this->DB->prepare($sql);
        $stmt->execute([$fecha, $fecha]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getByYear($fecha){
        
        $sql = "SELECT * FROM recargas WHERE YEAR(Fecha_Registro) = YEAR(?)";
        $stmt = $this->DB->prepare($sql);
        $stmt->execute([$fecha]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function create($data){
        
        $sql = "INSERT INTO recargas (Tarjeta, Monto, Id_Empleado, Fecha_Registro) VALUES (?, ?, ?, ?)";
        $stmt = $this->DB->prepare($sql);
        $stmt->execute([$data['Tarjeta'], $data['Monto'], $data['Id_Empleado'], $data['Fecha_Registro']]);
    }

    function get_id($id){
       
        $sql = "SELECT * FROM recargas WHERE Id_Recarga = ?";
        $stmt = $this->DB->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    function update($data){
        
        $sql = "UPDATE recargas SET Tarjeta = ?, Monto = ?, Id_Empleado = ?, Fecha_Hora = ? WHERE Id_Recarga = ?";
        $stmt = $this->DB->prepare($sql);
        $stmt->execute([$data['Tarjeta'], $data['Monto'], $data['Id_Empleado'], $data['Fecha_Registro'], $data['Id_Recarga']]);
    }
}

?>

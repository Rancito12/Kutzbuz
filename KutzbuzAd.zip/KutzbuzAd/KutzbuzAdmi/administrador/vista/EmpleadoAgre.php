<div class="container" style="margin-top: 80px">
    <div class="jumbotron">
        <h2>Crear Nuevo Empleado</h2>
    </div>

    <div class="container">
        <form action="index.php?action=store" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="Nombre">Nombre:</label>
                <input type="text" class="form-control" id="Nombre" name="Nombre" required>
            </div>

            <div class="form-group">
                <label for="ApellidoPater">Apellido Paterno:</label>
                <input type="text" class="form-control" id="ApellidoPater" name="ApellidoPater" required>
            </div>

            <div class="form-group">
                <label for="ApellidoMat">Apellido Materno:</label>
                <input type="text" class="form-control" id="ApellidoMat" name="ApellidoMat" required>
            </div>

            <div class="form-group">
                <label for="Telefono">Teléfono:</label>
                <input type="text" class="form-control" id="Telefono" name="Telefono" required>
            </div>

            <div class="form-group">
                <label for="Fecha_Registro">Fecha de Registro:</label>
                <input type="date" class="form-control" id="Fecha_Registro" name="Fecha_Registro" required>
            </div>

            <div class="form-group">
                <label for="Contraseña">Contraseña:</label>
                <input type="password" class="form-control" id="Contraseña" name="Contraseña" required>
            </div>

            <div class="form-group">
                <label for="ConfContra">Confirmar Contraseña:</label>
                <input type="password" class="form-control" id="ConfContra" name="ConfContra" required>
            </div>

            <div class="form-group">
                <label for="Foto">Foto:</label>
                <input type="file" class="form-control-file" id="Foto" name="NuevaFoto" required>
            </div>

            <button type="submit" class="btn btn-primary">Guardar Empleado</button>
        </form>
    </div>
</div>

<!-- Script para establecer la fecha actual en el campo de fecha -->
<script>
    function setDateTime() {
        const dateInput = document.getElementById('Fecha_Registro');
        const now = new Date();
        const offset = now.getTimezoneOffset();
        const localDate = new Date(now.getTime() - (offset * 60 * 1000));
        const localISODate = localDate.toISOString().slice(0, 10);
        dateInput.value = localISODate;
    }

    window.onload = setDateTime;
</script>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gráfica de Resultados</title>
    <!-- Incluir estilos CSS de Bootstrap o cualquier otro framework que estés usando -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Incluir la biblioteca de Chart.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
</head>
<body>
    <div class="container" style="margin-top: 80px;">
        <div class="jumbotron">
            <h2>Gráfica de Resultados</h2>
        </div>

        <div class="row">
            <div class="col-md-6">
                <canvas id="myChart" width="400" height="400"></canvas>
            </div>
            <div class="col-md-6">
                <h3>Detalles</h3>
                <ul class="list-group">
                    <li class="list-group-item">Total de Recargas del Mes: <?php echo $totalRecargas; ?></li>
                    <li class="list-group-item">Total de Empleados del Mes: <?php echo $totalEmpleados; ?></li>
                    <li class="list-group-item">Total de Usuarios del Mes: <?php echo $totalUsuarios; ?></li>
                    <li class="list-group-item">Resultado de la Operación: <?php echo $resultado; ?></li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // Obtener el contexto del canvas
        var ctx = document.getElementById('myChart').getContext('2d');

        // Datos para la gráfica
        var datosGrafica = {
            labels: <?php echo json_encode($datosGrafica['labels']); ?>,
            datasets: [{
                label: 'Resultado Mensual',
                data: <?php echo json_encode($datosGrafica['data']); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        };

        // Configuración de la gráfica
        var myChart = new Chart(ctx, {
            type: 'line',
            data: datosGrafica,
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        stepSize: 10
                    }
                }
            }
        });
    </script>
</body>
</html>

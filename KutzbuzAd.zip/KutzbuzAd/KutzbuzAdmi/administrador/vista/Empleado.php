<?php
// Empleado.php

// Obtener datos del empleado si están disponibles
$id_empleado = isset($empleado['Id_Empleado']) ? $empleado['Id_Empleado'] : '';
$nombre = isset($empleado['Nombre']) ? $empleado['Nombre'] : '';
$apellidoPater = isset($empleado['ApellidoPater']) ? $empleado['ApellidoPater'] : '';
$apellidoMat = isset($empleado['ApellidoMat']) ? $empleado['ApellidoMat'] : '';
$telefono = isset($empleado['Telefono']) ? $empleado['Telefono'] : '';
$fechaRegistro = isset($empleado['Fecha_Registro']) ? $empleado['Fecha_Registro'] : '';
$contraseña = isset($empleado['Contraseña']) ? $empleado['Contraseña'] : '';
$confContra = isset($empleado['ConfContra']) ? $empleado['ConfContra'] : '';
$foto = isset($empleado['Foto']) ? $empleado['Foto'] : '';

?>

<div class="container" style="margin-top: 80px">
    <div class="jumbotron">
        <h2>Editar Empleado</h2>
    </div>

    <div class="container">
        <form action="index.php?action=update&Id_Empleado=<?php echo $id_empleado; ?>" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="Nombre">Nombre:</label>
                <input type="text" class="form-control" id="Nombre" name="Nombre" value="<?php echo htmlspecialchars($nombre); ?>" required>
            </div>
            <div class="form-group">
                <label for="ApellidoPater">Apellido Paterno:</label>
                <input type="text" class="form-control" id="ApellidoPater" name="ApellidoPater" value="<?php echo htmlspecialchars($apellidoPater); ?>" required>
            </div>
            <div class="form-group">
                <label for="ApellidoMat">Apellido Materno:</label>
                <input type="text" class="form-control" id="ApellidoMat" name="ApellidoMat" value="<?php echo htmlspecialchars($apellidoMat); ?>" required>
            </div>
            <div class="form-group">
                <label for="Telefono">Teléfono:</label>
                <input type="text" class="form-control" id="Telefono" name="Telefono" value="<?php echo htmlspecialchars($telefono); ?>" required>
            </div>
            <div class="form-group">
                <label for="Fecha_Registro">Fecha de Registro:</label>
                <input type="date" class="form-control" id="Fecha_Registro" name="Fecha_Registro" value="<?php echo htmlspecialchars($fechaRegistro); ?>" required>
            </div>
            <div class="form-group">
                <label for="Contraseña">Contraseña:</label>
                <input type="password" class="form-control" id="Contraseña" name="Contraseña" value="<?php echo htmlspecialchars($contraseña); ?>" required>
            </div>
            <div class="form-group">
                <label for="ConfContra">Confirmar Contraseña:</label>
                <input type="password" class="form-control" id="ConfContra" name="ConfContra" value="<?php echo htmlspecialchars($confContra); ?>" required>
            </div>
            <div class="form-group">
                <label for="Foto">Foto Actual:</label>
                <br>
                <img src="<?php echo htmlspecialchars($foto); ?>" class="img-thumbnail" style="max-width: 200px;" alt="Foto de perfil">
                <br><br>
                <label for="NuevaFoto">Seleccionar nueva foto:</label>
                <input type="file" class="form-control-file" id="NuevaFoto" name="NuevaFoto">
            </div>
            <button type="submit" class="btn btn-primary">Actualizar Empleado</button>
        </form>
    </div>
</div>

<!-- Script para establecer la fecha actual en el campo de fecha -->
<script>
    function setDateTime() {
        const dateInput = document.getElementById('Fecha_Registro');
        const now = new Date();
        const offset = now.getTimezoneOffset();
        const localDate = new Date(now.getTime() - (offset * 60 * 1000));
        const localISODate = localDate.toISOString().slice(0, 10);
        dateInput.value = localISODate;
    }

    window.onload = setDateTime;
</script>

<div class="container" style="margin-top: 80px">
    <div class="jumbotron">
        <h2>Catalogo de Recargas</h2>
    </div>

    <!-- Tabla de recargas -->
    <div class="container">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Id Tarjeta</th>
                    <th>Monto</th>
                    <th>Id Empleado</th>
                    <th>Fecha</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($recargas as $recarga): ?>
                    <tr>
                        <td><?php echo $recarga['Tarjeta']; ?></td>
                        <td><?php echo $recarga['Monto']; ?></td>
                        <td><?php echo $recarga['Id_Empleado']; ?></td>
                        <td><?php echo $recarga['Fecha_Registro']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

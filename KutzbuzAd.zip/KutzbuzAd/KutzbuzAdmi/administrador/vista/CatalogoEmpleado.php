<div class="container" style="margin-top: 80px">
    <div class="jumbotron">
        <h2>Catalogo de Empleados</h2>
    </div>

    <div class="row">
        <?php foreach($empleados as $empleado): ?>
            <div class="col-md-4 mb-4">
    <div class="card">
        <img src="<?php echo htmlspecialchars($empleado['Foto']); ?>" class="card-img-top" alt="Foto de perfil">
        <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($empleado['Nombre']); ?></h5>
                        <p class="card-text"><strong>ApellidoPater: </strong><?php echo htmlspecialchars($empleado['ApellidoPater']); ?></p>
                        <p class="card-text"><strong>ApellidoMat: </strong><?php echo htmlspecialchars($empleado['ApellidoMat']); ?></p>
                        <p class="card-text"><strong>Telefono: </strong><?php echo htmlspecialchars($empleado['Telefono']); ?></p>
                        <p class="card-text"><strong>Fecha_Registro: </strong><?php echo htmlspecialchars($empleado['Fecha_Registro']); ?></p>
                        <p class="card-text"><strong>Contraseña: </strong><?php echo hidePassword($empleado['Contraseña']); ?></p>
                        <!-- Evitar mostrar ConfContra o datos sensibles directamente -->
                        <a href="index.php?action=edit&Id_Empleado=<?php echo $empleado['Id_Empleado']; ?>" class="btn btn-primary">Editar</a>
                        <a href="#" onclick="confirmDelete(<?php echo $empleado['Id_Empleado']; ?>)" class="btn btn-danger">Eliminar</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Script para confirmación de eliminación -->
<script>
    function confirmDelete(id) {
        if (confirm('¿Estás seguro de que deseas eliminar este empleado?')) {
            window.location.href = 'index.php?action=destroy&Id_Empleado=' + id;
        }
    }
</script>

<?php
// Función para ocultar los primeros 4 caracteres de la contraseña
function hidePassword($password) {
    if (strlen($password) > 4) {
        $hidden_part = str_repeat('*', strlen($password) - 4);
        $visible_part = substr($password, -4);
        return $hidden_part . $visible_part;
    } else {
        return str_repeat('*', strlen($password));
    }
}
?>

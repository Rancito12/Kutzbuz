<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recargas</title>
    <script src="https://unpkg.com/jsqr/dist/jsQR.js"></script>
    <style>
        /* Estilo del modal */
        .modal {
            display: none; /* Ocultar el modal por defecto */
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background-color: #fff;
            padding: 30px;
            border: 3px solid #007bff;
            border-radius: 8px;
            width: 80%;
            max-width: 600px;
            text-align: center;
            position: relative;
        }

        .close {
            color: #007bff;
            position: absolute;
            top: 0;
            right: 20px;
            font-size: 30px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover,
        .close:focus {
            color: #0056b3;
        }

        #video {
            border: 1px solid #007bff;
            border-radius: 5px;
            width: 100%;
            height: auto;
        }

        #canvas {
            display: none;
        }
    </style>
</head>
<body>
<div class="container" style="margin-top: 80px">
    <div class="jumbotron">
        <h2>Agregar Recarga</h2>
    </div>
    <div class="container">
        <form action="" method="post">
            <div class="form-group">
                <label for="Tarjeta">Tarjeta:</label>
                <input type="text" class="form-control" id="Tarjeta" name="Tarjeta" required>
            </div>
            <div class="form-group">
                <label for="Monto">Monto:</label>
                <input type="number" step="0.01" class="form-control" id="Monto" name="Monto" required>
            </div>
            <div class="form-group">
                <label for="Id_Empleado">Id Empleado:</label>
                <input type="text" class="form-control" id="Id_Empleado" name="Id_Empleado" required>
            </div>
            <div class="form-group">
                <label for="Fecha_Registro">Fecha:</label>
                <input type="date" class="form-control" id="Fecha_Registro" name="Fecha_Registro" required>
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Agregar Recarga</button>
        </form>
        <button id="scan-btn" class="btn btn-secondary" style="margin-top: 20px;">Escanear QR</button>
        <input type="file" id="fileInput" accept="image/*" style="display: none;"/>
        <label for="fileInput">
            <button id="uploadFileBtn">Cargar Imagen</button>
        </label>
    </div>
</div>

<!-- The Modal -->
<div id="myModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <video id="video" width="300" height="200"></video>
        <canvas id="canvas"></canvas>
        <div id="result"></div>
    </div>
</div>

<script>
    let video = document.getElementById('video');
    let canvas = document.getElementById('canvas');
    let resultDiv = document.getElementById('result');
    let stream;
    let intervalId;

    function setDateTime() {
        const dateInput = document.getElementById('Fecha_Registro');
        const now = new Date();
        const localISODate = now.toISOString().slice(0, 10);
        dateInput.value = localISODate;
    }

    function scanQRCodeFromVideo() {
        if (video.readyState === video.HAVE_ENOUGH_DATA && video.videoWidth > 0 && video.videoHeight > 0) {
            const context = canvas.getContext('2d');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, canvas.width, canvas.height);
            if (code) {
                resultDiv.innerHTML = `Código QR detectado: ${code.data}`;
                document.getElementById('Tarjeta').value = code.data;
                stopCamera(); // Detener cámara automáticamente al detectar un código QR
                document.getElementById("myModal").style.display = "none"; // Cerrar modal
            } else {
                resultDiv.innerHTML = 'No se detectó ningún código QR.';
            }
        }
    }

    function scanQRCodeFromFile(file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = new Image();
            img.onload = function() {
                const context = canvas.getContext('2d');
                canvas.width = img.width;
                canvas.height = img.height;
                context.drawImage(img, 0, 0);
                const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                const code = jsQR(imageData.data, canvas.width, canvas.height);
                if (code) {
                    resultDiv.innerHTML = `Código QR detectado: ${code.data}`;
                    document.getElementById('Tarjeta').value = code.data;
                    document.getElementById("myModal").style.display = "none"; // Cerrar modal
                } else {
                    resultDiv.innerHTML = 'No se detectó ningún código QR.';
                }
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    function startCamera() {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
                .then(function(s) {
                    stream = s;
                    video.srcObject = s;
                    video.play();
                    // Esperar a que el video esté listo antes de comenzar a escanear
                    video.addEventListener('loadeddata', function() {
                        intervalId = setInterval(scanQRCodeFromVideo, 1000); // Escanear cada segundo
                    });
                })
                .catch(function(error) {
                    console.error("Error al acceder a la cámara: ", error);
                    alert("No se pudo acceder a la cámara. Asegúrate de que los permisos estén habilitados.");
                });
        } else {
            alert("La cámara no está disponible en este navegador.");
        }
    }

    function stopCamera() {
        if (stream) {
            let tracks = stream.getTracks();
            tracks.forEach(track => track.stop());
            video.srcObject = null;
            clearInterval(intervalId); // Detener el intervalo de escaneo
        }
    }

    document.getElementById('scan-btn').addEventListener('click', function() {
        const modal = document.getElementById("myModal");
        modal.style.display = "flex"; // Mostrar el modal
        startCamera();
    });

    document.querySelector(".close").addEventListener('click', function() {
        const modal = document.getElementById("myModal");
        modal.style.display = "none";
        stopCamera();
    });

    window.onclick = function(event) {
        const modal = document.getElementById("myModal");
        if (event.target === modal) {
            modal.style.display = "none";
            stopCamera();
        }
    }

    document.getElementById('fileInput').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            scanQRCodeFromFile(file);
        }
    });

    document.getElementById('uploadFileBtn').addEventListener('click', function() {
        document.getElementById('fileInput').click();
    });

    // Asegúrate de que el modal no se muestre al cargar la página
    window.onload = function() {
        setDateTime();
        const modal = document.getElementById("myModal");
        modal.style.display = "none"; // Asegúrate de que el modal esté oculto
    };
</script>

</body>
</html>

<?php

$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "administrador"; 

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables
$saldoActual = "";
$Tarjeta = "";

// Obtener el número de tarjeta del formulario si se envió
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Convertir el array a una cadena si 'Tarjeta' es un array
    if (isset($_POST['Tarjeta']) && is_array($_POST['Tarjeta'])) {
        $Tarjeta = implode('', $_POST['Tarjeta']);
    }

    // Preparar y ejecutar la consulta para sumar los montos agrupados por Tarjeta
    $sql = "SELECT SUM(Monto) as Monto FROM recargas WHERE Tarjeta = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error al preparar la consulta: " . $conn->error);
    }
    $stmt->bind_param("s", $Tarjeta);
    $stmt->execute();
    $stmt->bind_result($saldo);
    
    // Obtener el saldo
    if ($stmt->fetch()) {
        $saldoActual = $saldo !== null ? $saldo : "No encontrado";
    } else {
        $saldoActual = "No encontrado";
    }
    
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saldo</title>
    <link rel="stylesheet" href="../KUTZBUZADMI/css/cons.css">
</head>
<body>
    <div class="container">
        <form class="formulario" method="post">
            <h2>Consulta tu saldo!!</h2>
            <center>
                <div class="qr-code">
                    <img src="../KUTZBUZADMI/img/logo.png" width="150px" height="150px" alt="Código QR de la Tarjeta">
                </div>
            </center>
            <label for="numeroTarjeta">Número de Tarjeta:</label>
            <div class="id-input">
                <?php
                // Volver a mostrar los campos del número de tarjeta
                if ($Tarjeta) {
                    for ($i = 0; $i < strlen($Tarjeta); $i++) {
                        echo '<input type="text" value="' . htmlspecialchars($Tarjeta[$i]) . '" maxlength="1" readonly>';
                    }
                } else {
                    for ($i = 0; $i < 6; $i++) {
                        echo '<input type="text" name="Tarjeta[]" maxlength="1">';
                    }
                }
                ?>
            </div>
            <label for="saldoActual">Saldo Actual:</label>
            <input type="text" id="saldoActual" name="saldoActual" value="<?php echo htmlspecialchars($saldoActual); ?>" readonly>

            <div class="botones">
                <button type="button" class="cerrar" onclick="cerrarVentana()">Cerrar</button>
                <button type="submit" class="consultar">Consultar</button>
            </div>
        </form>
    </div>
    <script>
      function cerrarVentana() {
        window.location.href = 'principal.php';
      }

      function handleInput(event) {
        var input = event.target;
        if (input.value.length >= input.maxLength) {
            var nextInput = input.nextElementSibling;
            if (nextInput && nextInput.tagName === "INPUT") {
                nextInput.focus();
            }
        }
      }

      function handleBackspace(event) {
        var input = event.target;
        if (event.key === "Backspace" && input.value.length === 0) {
            var prevInput = input.previousElementSibling;
            if (prevInput && prevInput.tagName === "INPUT") {
                prevInput.focus();
            }
        }
      }

      document.querySelectorAll('.id-input input').forEach(function(input) {
        input.addEventListener('input', handleInput);
        input.addEventListener('keydown', handleBackspace);
      });
    </script>
</body>
</html>

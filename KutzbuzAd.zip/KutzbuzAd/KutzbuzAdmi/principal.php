<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>KUTZBUZ</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href= " " />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link rel="stylesheet" href="../KUTZBUZADMI/css/estilo.css">
    </head>
    <body 
    

    
    id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
                <div class="container">
                    <a class="navbar-brand"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                        Menú
                        <i class="fas fa-bars ms-1"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                        <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                            <li class="nav-item"><a class="nav-link" href="#services">Servicio</a></li>
                            <li class="nav-item"><a class="nav-link" href="#portfolio">Portafolio</a></li>
                            <li class="nav-item"><a class="nav-link" href="#about">Sobre nosotros</a></li>
                            <li class="nav-item"><a class="nav-link" href="consulta.php">Consultar</a></li>
                            <li class="nav-item"><a class="nav-link" href="recargas.php">Recarga</a></li>
                            <li class="nav-item"><a class="nav-link" href="Generar.php">Generar QR</a></li>
                            <li class="nav-item"><a class="nav-link" href="#team">Team</a></li>
                            <li class="nav-item"><a class="nav-link" href="#contact">Contacto</a></li>
                            <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item dropdown">
                                        <button class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" style="background-color: transparent; border: none;">
                                            <span style="color: white;">SIGN IN</span>
                                        </button>
                                        <ul class="dropdown-menu" style="background-color: transparent; border: none;">
                                            <li><a class="dropdown-item" href="log.php" style="color: white;" onmouseover="this.style.color='black'" onmouseout="this.style.color='white'">Login</a></li>
                                            <li><a class="dropdown-item" href="registro.php" style="color: white;" onmouseover="this.style.color='black'" onmouseout="this.style.color='white'">Registre</a></li>
                                            <li><a class="dropdown-item" href="cerrar.php" style="color: white;" onmouseover="this.style.color='black'" onmouseout="this.style.color='white'">Logout</a></li>
                                       
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </ul>
                    </div>
                </div>
            </nav>
            
            <script>
                window.addEventListener("scroll", function() {
                    var navbar = document.getElementById("mainNav");
                    if (window.pageYOffset > 0) {
                        navbar.classList.add("bg-black");
                    } else {
                        navbar.classList.remove("bg-black");
                    }
                });
            </script>            
       
       <header class="masthead" style="background-image: url('../KUTZBUZADMI/img/portada2.jpg');">
        <div class="container">
            <div class="masthead-subheading">El sistema de cobro que simplifica tu vida!</div>
            <div class="masthead-heading text-uppercase">KUTZBUZ</div>
            <!-- Nuevo-->
        
            <a class="btn btn-primary btn-xl text-uppercase" href="rutas.php">Rutas Disponibles</a>
            <!--Fin Nuevo-->
        </div>
    </header>
       
        <!-- Services-->
        <section class="page-section" id="services">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Servicios</h2>
                    <h3 class="section-subheading text-muted">"Nuestra misison es proporcionarle un servicio impecable y una solucion efectiva"</h3>
                </div>
                <div class="row text-center">
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-primary"></i>
                            <i class="fas fa-credit-card fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="my-3">Recargas y Consultas</h4>
                        <p class="text-muted">Nuestra plataforma de gestión de recargas y consultas no solo te permite recargar tu saldo de manera rápida y segura, sino que también te proporciona información en tiempo real sobre el estado de tus consultas, garantizando una experiencia fluida y confiable en todo momento.</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-primary"></i>
                            <i class="fas fa-bus fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="my-3">Rutas</h4>
                        <p class="text-muted">Nuestro servicio de planificación de rutas no solo te ayuda a encontrar el camino más corto entre dos puntos, sino que también obtén el tiempo estimado de llegada más preciso gracias a nuestras actualizaciones de tráfico en tiempo real.</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-primary"></i>
                            <i class="fas fa-lock fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="my-3">Seguridad</h4>
                        <p class="text-muted">Nuestra plataforma prioriza tu seguridad en cada paso. Implementamos medidas avanzadas de protección de datos y encriptación para garantizar la confidencialidad de tus transacciones y la integridad de tu información personal en todo momento.</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- Portfolio Grid-->
        <section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Portafolio</h2>
                    <h3 class="section-subheading text-muted">Servicios KUTZBUZ</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 1-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal1">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="../KUTZBUZADMI/img/portafolio1.jpg " alt="..." />
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 2-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal2">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="../KUTZBUZADMI/img/portafolio2.jpg" alt="..." />
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 3-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal3">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="../KUTZBUZADMI/img/portafolio3.jpg" alt="..." />
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
                        <!-- Portfolio item 4-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal4">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="../KUTZBUZADMI/img/portafolio4.jpg " alt="..." />
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4 mb-sm-0">
                        <!-- Portfolio item 5-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal5">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="../KUTZBUZADMI/img/portafolio5.jpg" alt="..." />
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <!-- Portfolio item 6-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal6">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="../KUTZBUZADMI/img/portafolio6.jpg" alt="..." />
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About-->
        <section class="page-section" id="about">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">SOBRE NOSOTROS</h2>
                    <h3 class="section-subheading text-muted">"Somos más que un autobús, somos tu puente hacia el mundo."</h3>
                </div>
                <ul class="timeline">
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="../KUTZBUZADMI/img/equipo.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Febrero 2023</h4>
                                <h4 class="subheading">KUTZBUZ</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">En el corazón de nuestra empresa ,está el compromiso con la excelencia operativa, la atención al detalle y el bienestar de nuestros pasajeros. Desde el diseño de nuestras rutas hasta poder  crear una red de conexiones confiables y accesibles que enriquezcan la vida de las comunidades que servimos. Por lo tanto no solo ofreceremos un medio de transporte eficiente, seguro y confiable, sino que también fomente una experiencia de viaje excepcional, donde la comodidad, la puntualidad y la atención al cliente sean nuestras prioridades principales</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid"  src="../KUTZBUZADMI/img/logo.png" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Marzo 2023</h4>
                                <h4 class="subheading">Creación del logo</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Nosotros escogimos el pavo real para representar la marca del sistema ya que el protege su territorio, lo cual significa poder proteger el sistema donde el usuario pueda usar el sistema de forma segura e inteligente.</p></div>
                        </div>
                    </li>
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="../KUTZBUZADMI/img/descargar.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4 class="subheading">Misión</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Ofrecer un sistema de recargas de tarjeta para el transporte público de manera eficiente y segura.</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="../KUTZBUZADMI/img/images.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4 class="subheading">Visión</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Ser líder en la transformación digital de la industria del transporte público, brindando soluciones innovadoras que aumenten la movilidad y promuevan la inclusión a zonas rurales. Ser reconocidos por su confiabilidad, seguridad y facilidad de uso</p></div>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
        <!-- Team-->
        <section class="page-section bg-light" id="team">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">NUESTRO INCREÍBLE EQUIPO</h2>
                    <h3 class="section-subheading text-muted">Juntos superamos desafíos y celebramos triunfo <br> "El éxito es el resultado del trabajo en equipo."</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="team-member">
                            <img class="mx-auto rounded-circle" src="../KUTZBUZADMI/img/alumnno1.jpg" alt="..." />
                            <h4>Daana Quiñones</h4>
                            <p class="text-muted">Programadora principal</p>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Parveen Anand Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Parveen Anand Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Parveen Anand LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                            <img class="mx-auto rounded-circle" src="../KUTZBUZADMI/img/alumno2.jpg" alt="..." />
                            <h4>Lilia Tamayo</h4>
                            <p class="text-muted">Diseñadora principal</p>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Diana Petersen Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Diana Petersen Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Diana Petersen LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                            <img class="mx-auto rounded-circle" src="../KUTZBUZADMI/img/alumno3.jpg" alt="..." />
                            <h4>Adriana Dzib</h4>
                            <p class="text-muted">Lider de proyecto</p>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 mx-auto text-center"><p class="large text-muted">"Nuestro equipo de tres mujeres desarrolladoras es un ejemplo de colaboración, innovación y dedicación. Con una pasión compartida por la tecnología, trabajamos juntas para superar desafíos, fomentar la creatividad y crear soluciones impactantes que impulsen el cambio en el mundo digital."</p></div>
                </div>
            </div>
        </section>
        <!-- Contact-->
        <section class="page-section" id="contact">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Contactanos</h2>
                    <h3 class="section-subheading text-muted">Estamos aqui para resolver tus dudas. Envianos un mensaje!!</h3>
                </div>
                <!-- * * * * * * * * * * * * * * *-->
                <!-- * * SB Forms Contact Form * *-->
                <!-- * * * * * * * * * * * * * * *-->
                <!-- This form is pre-integrated with SB Forms.-->
                <!-- To make this form functional, sign up at-->
                <!-- https://startbootstrap.com/solution/contact-forms-->
                <!-- to get an API token!-->
                <form id="contactForm" data-sb-form-api-token="API_TOKEN">
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-6">
                            <div class="form-group">
                                <!-- Name input-->
                                <input class="form-control" id="name" type="text" placeholder="Nombre *" data-sb-validations="required" />
                                <div class="invalid-feedback" data-sb-feedback="name:required">A name is required.</div>
                            </div>
                            <div class="form-group">
                                <!-- Email address input-->
                                <input class="form-control" id="email" type="email" placeholder="Email *" data-sb-validations="required,email" />
                                <div class="invalid-feedback" data-sb-feedback="email:required">An email is required.</div>
                                <div class="invalid-feedback" data-sb-feedback="email:email">Email is not valid.</div>
                            </div>
                            <div class="form-group mb-md-0">
                                <!-- Phone number input-->
                                <input class="form-control" id="phone" type="tel" placeholder="telefono o celular*" data-sb-validations="required" />
                                <div class="invalid-feedback" data-sb-feedback="phone:required">A phone number is required.</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group form-group-textarea mb-md-0">
                                <!-- Message input-->
                                <textarea class="form-control" id="message" placeholder="Your Message *" data-sb-validations="required"></textarea>
                                <div class="invalid-feedback" data-sb-feedback="message:required">A message is required.</div>
                            </div>
                        </div>
                    </div>
                    <!-- Submit success message-->
                    <!---->
                    <!-- This is what your users will see when the form-->
                    <!-- has successfully submitted-->
                    <div class="d-none" id="submitSuccessMessage">
                        <div class="text-center text-white mb-3">
                            <div class="fw-bolder">Form submission successful!</div>
                            To activate this form, sign up at
                            <br />
                            <a href="https://startbootstrap.com/solution/contact-forms">https://startbootstrap.com/solution/contact-forms</a>
                        </div>
                    </div>
                    <!-- Submit error message-->
                    <!---->
                    <!-- This is what your users will see when there is-->
                    <!-- an error submitting the form-->
                    <div class="d-none" id="submitErrorMessage"><div class="text-center text-danger mb-3">Error sending message!</div></div>
                    <!-- Submit Button-->
                    <div class="text-center"><button class="btn btn-primary btn-xl text-uppercase disabled" id="submitButton" type="submit">Send Message</button></div>
                </form>
            </div>
        </section>
        <!-- Footer-->
        <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-start">Copyright &copy; Your Website 2023</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="#!">Privacy Policy</a>
                        <a class="link-dark text-decoration-none" href="#!">Terms of Use</a>
                    </div>
                </div>
            </div>
            
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
         
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
   
   
   
    </body>
</html>

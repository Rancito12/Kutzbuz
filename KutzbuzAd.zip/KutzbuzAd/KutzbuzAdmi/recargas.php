

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recarga de Tarjeta</title>
    <link rel="stylesheet" href="../KUTZBUZADMI/css/recargas.css">
</head>
<body>
    <div class="container">
        <img src="../KUTZBUZADMI/img/logo.png" alt="Logo" class="logo">
        <h1>Recarga de Tarjeta</h1>
        <form id="recargaForm">
            <div class="qr-code">
                 </div>
            <label for="Tarjeta">ID de la Tarjeta:</label>
            <div class="id-input">
                <input type="text" id="tarjetaId1" maxlength="1" required>
                <input type="text" id="tarjetaId2" maxlength="1" required>
                <input type="text" id="tarjetaId3" maxlength="1" required>
                <input type="text" id="tarjetaId4" maxlength="1" required>
                <input type="text" id="tarjetaId5" maxlength="1" required>
                <input type="text" id="tarjetaId6" maxlength="1" required>
            </div>
            
            <label for="Monto">Monto:</label>
            <input type="number" id="Monto" name="Monto" required>
            
            <label for="Fecha_Registro">Fecha y Hora:</label>
            <input type="datetime-local" id="Fecha_Registro" name="Fecha_Registro" required>
            
            <div class="botones">
                
            <button type="button" id="paypalButton">Pagar con PayPal</button>
                <button type="button" id="pagarButton">Pagar</button>
                <button type="button" class="cerrar" onclick="cerrarVentana()">Cerrar</button>
            </div>
        </form>
        <p id="successMessage" style="display:none;">¡Recarga exitosa!</p>
    </div>

    <script>
        function cerrarVentana() {
            window.location.href = 'principal.php';
        }

        function handleInput(event) {
            var input = event.target;
            if (input.value.length >= input.maxLength) {
                var nextInput = input.nextElementSibling;
                if (nextInput && nextInput.tagName === "INPUT") {
                    nextInput.focus();
                }
            }
        }

        function handleBackspace(event) {
            var input = event.target;
            if (event.key === "Backspace" && input.value.length === 0) {
                var prevInput = input.previousElementSibling;
                if (prevInput && prevInput.tagName === "INPUT") {
                    prevInput.focus();
                }
            }
        }


        document.getElementById('paypalButton').addEventListener('click', function() {
            // Verificar si los campos están llenos antes de redirigir
            var idInputs = document.querySelectorAll('.id-input input');
            var montoInput = document.getElementById('Monto');
            var fechaHoraInput = document.getElementById('Fecha_Registro');

            var camposLlenos = Array.from(idInputs).every(input => input.value.trim() !== "") &&
                               montoInput.value.trim() !== "" &&
                               fechaHoraInput.value.trim() !== "";

            if (camposLlenos) {
                window.location.href = "https://www.paypal.com"; 
            } else {
                }
        });

        document.querySelectorAll('.id-input input').forEach(function(input) {
            input.addEventListener('input', handleInput);
            input.addEventListener('keydown', handleBackspace);
        });

        document.getElementById('pagarButton').addEventListener('click', function() {
            var idInputs = document.querySelectorAll('.id-input input');
            var MontoInput = document.getElementById('Monto');
            var FechaInput = document.getElementById('Fecha_Registro');

            var Tarjeta = Array.from(idInputs).map(input => input.value).join('');
            var Monto = MontoInput.value;
            var Fecha_Registro = FechaInput.value;

            if (Tarjeta && Monto && Fecha_Registro) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "proc.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        document.getElementById('successMessage').style.display = 'block';
                    }
                };
                xhr.send("Tarjeta=" + Tarjeta + "&Monto=" + Monto + "&Fecha_Registro=" + Fecha_Registro);
            } else {
                alert("Por favor, llene todos los campos antes de continuar.");
            }
        });

        function setDateTime() {
            const dateTimeInput = document.getElementById('Fecha_Registro');
            const now = new Date();
            const offset = now.getTimezoneOffset();
            const localDate = new Date(now.getTime() - (offset * 60 * 1000));
            const localISODate = localDate.toISOString().slice(0, 16);
            dateTimeInput.value = localISODate;
        }

        window.onload = setDateTime;
    </script>
</body>
</html>
 
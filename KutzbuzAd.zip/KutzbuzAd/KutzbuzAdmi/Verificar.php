<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "administrador"; 

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$Id_Empleado = $_POST['Id_Empleado'];
$contrasena = $_POST['contraseña'];


$sql = "SELECT nombre FROM empleados WHERE Id_Empleado = ? AND contraseña = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $Id_Empleado, $contrasena);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Obtener el nombre del usuario
    $row = $result->fetch_assoc();
    $nombre = $row['nombre'];
    // mandar con un mensaje de éxito
    header("Location: ../KUTZBUZADMI/reg.php?success=1&nombre=" . urlencode($nombre));
} else {
    // mandar con un mensaje de error
    header("Location: ../KUTZBUZADMI/reg.php?error=1");
}

// Cerrar conexión
$stmt->close();
$conn->close();
?>
<?php

$servidor_bd = 'localhost';
$usuario_bd = 'root';
$contrasena_bd = '';
$nombre_bd = 'administrador';

// Crear una conexión a la base de datos
$conexion = new mysqli($servidor_bd, $usuario_bd, $contrasena_bd, $nombre_bd);

// Verificar si la conexión fue exitosa
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

$mensaje = "";
$mostrar_boton_especial = false;

// Función para iniciar sesión
function iniciar_sesion($conexion, $correo, $contraseña) {
    global $mensaje, $mostrar_boton_especial;
    
    // Verificación específica
    if ($correo === 'Kutzbuz@gmail.com' && $contraseña === 'Kutzbuz09') {
        $mostrar_boton_especial = true;
        return;
    }

    $query = $conexion->prepare("SELECT nombre, contraseña FROM usuarios WHERE correo = ?");
    $query->bind_param("s", $correo);
    $query->execute();
    $query->store_result();
    $query->bind_result($nombre, $contrasena_hash);
    
    if ($query->num_rows > 0) {
        $query->fetch();
        if (password_verify($contraseña, $contrasena_hash)) {
            session_start();
            $_SESSION['usuario'] = $correo;
            $_SESSION['nombre'] = $nombre;
            $mensaje = "Inicio de sesión exitoso. Bienvenido, $nombre!";
        } else {
            $mensaje = "Contraseña incorrecta.";
        }
    } else {
        $mensaje = "Usuario no encontrado.";
    }
    
    $query->close();
}

// Verificar la acción del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = filter_var($_POST['accion'], FILTER_SANITIZE_STRING);
    $correo = filter_var($_POST['correo'], FILTER_SANITIZE_EMAIL);
    $contraseña = filter_var($_POST['contraseña'], FILTER_SANITIZE_STRING);

    if ($accion === 'login') {
        iniciar_sesion($conexion, $correo, $contraseña);
    } else {
        $mensaje = "Acción no válida.";
    }
}

// Cerrar la conexión
$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="../KUTZBUZADMI/css/log.css">
</head>
<body>
    <h2>Login</h2>
    <form action="" method="post">
        <input type="hidden" name="accion" value="login">
        <label for="correo_login">Correo:</label>
        <input type="email" id="correo_login" name="correo" required><br><br>
        <label for="contrasena_login">Contraseña:</label>
        <input type="password" id="contrasena_login" name="contraseña" required><br><br>
        <input type="submit" value="Iniciar Sesión">
    </form>

    <?php if ($mostrar_boton_especial): ?>
        <form action="reg.php" method="get">
            <button type="submit">Kutzbuz</button>
        </form>
    <?php endif; ?>

    <form action="principal.php" method="get">
        <button type="submit">Ir a Principal</button>
        
    </form>

    <!-- Modal -->
    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p><?php echo htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8'); ?></p>
        </div>
    </div>

    <script>
        var mensaje = "<?php echo htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8'); ?>";
        if (mensaje !== "") {
            document.getElementById('modal').style.display = 'block';
        }

        document.querySelector('.close').onclick = function() {
            document.getElementById('modal').style.display = 'none';
        };
    </script>
</body>
</html>

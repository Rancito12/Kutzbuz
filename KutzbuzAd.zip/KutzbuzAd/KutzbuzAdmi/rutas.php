<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rutas</title>
    <style>
        body {
            background-color: Teal;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }
        .card {
            border: 1px solid black;
            overflow: hidden;
            background-color: black;
            color: white;
            text-align: center;
        }
        .card img {
            width: 80%;
            height: 60%;
        }
        .card-title {
            color: gold;
            margin: 0;
            padding: 1px 0;
        }
        .card-description {
            padding: 1px;
        }
        .btn-google-maps {
            background-color: gold;
            color: black;
            padding: 10px;
            text-decoration: none;
            display: inline-block;
            margin: 5px 0;
        }
        .btn-google-maps:hover {
            background-color: #ffcc00;
        }
        .btn-back {
            background-color: black;
            color: gold;
            padding: 10px 20px;
            text-decoration: none;
            display: inline-block;
            margin: 20px 0;
            border: 1px solid gold;
        }
        .btn-back:hover {
            background-color: #333;
        }
    </style>
</head>
<body>
    <?php
        $users = [
            [
                'name' => 'Circuito Rojo',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://th.bing.com/th/id/OIP.fvtZcCt1tF7UTSkpz95ItQAAAA?w=320&h=180&c=7&r=0&o=5&pid=1.7',
                'link' => 'https://maps.app.goo.gl/n4r73aRrNJ3MtJUW8'
            ],
            [
                'name' => 'Circuito Metropolitano',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://th.bing.com/th/id/OIP.Nrhepux1erJ4zlnqD1EwhAHaEo?rs=1&pid=ImgDetMain',
                'link' => 'https://maps.app.goo.gl/ZJitKbZgAXgCkkP4A'
            ],
            [
                'name' => 'Centro - Umán',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://th.bing.com/th/id/OIP.z6AZg3z_bHjet11tFG0AygHaFj?rs=1&pid=ImgDetMain',
                'link' => 'https://maps.app.goo.gl/pCBfjqcTzbnRVDph6'
            ],
            [
                'name' => 'Villa Magna',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://th.bing.com/th/id/OIP.ss-fx8MPjtzSRGmNqwZ3QwHaEX?rs=1&pid=ImgDetMain',
                'link' => 'https://maps.app.goo.gl/9ikqjmrUEcthXxu26'
            ],
            [
                'name' => 'Xmatkuil',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://laverdadnoticias.com/__export/1674582429797/sites/laverdad/img/2023/01/24/transporte_puxblico_mexrida.jpeg_1834138182.jpeg',
                'link' => 'https://maps.app.goo.gl/MiZWjMWWMpK9kedt9'
            ],
            [
                'name' => 'San Marcos',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://th.bing.com/th/id/OIP.NLcS4go_XXUjBhvmh0KNcQHaGS?rs=1&pid=ImgDetMain',
                'link' => 'https://maps.app.goo.gl/Q7auDjaK4Kx8copz6'
            ],
            [
                'name' => 'Poniente y Universidades',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://th.bing.com/th/id/OIP.IGw4TFXdtDUY_NDhmNPuhAHaEK?rs=1&pid=ImgDetMain',
                'link' => 'https://maps.app.goo.gl/n4r73aRrNJ3MtJUW8'
            ],
            [
                'name' => 'Tren Maya',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://laverdadnoticias.com/img/2022/08/03/va_y_ven_tarifa.jpeg',
                'link' => 'https://maps.app.goo.gl/pCBfjqcTzbnRVDph6'
            ],
            [
                'name' => 'Aeropuerto',
                'Description' => '5 am - 11 pm',
                'photo' => 'https://th.bing.com/th/id/R.e6c9226b0d1c0038886a15f6d27f3ea3?rik=P%2byMeImvqsO%2bUg&riu=http%3a%2f%2fwww.yucatan.gob.mx%2fdocs%2fsaladeprensa%2f7110_1_278.jpg&ehk=ZAIedNTi60MIp77vmf3MI8pVKo31gPjhXJnqLugOFHM%3d&risl=&pid=ImgRaw&r=0',
                'link' => 'https://maps.app.goo.gl/cz7o7DwPyARQkotB6'
            ],
        ];
    ?>

    <div class="grid-container">
        <?php foreach ($users as $user): ?>
        <div class="card">
            <img src="<?php echo $user['photo']; ?>" alt="Foto de <?php echo $user['name']; ?>">
            <h2 class="card-title"><?php echo $user['name']; ?></h2>
            <p class="card-description"><?php echo $user['Description']; ?></p>
            <a href="<?php echo $user['link']; ?>" class="btn-google-maps">Ver en Google Maps</a>
        </div>
        <?php endforeach; ?>
    </div>
    <a href="principal.php" class="btn-back">Cerrar</a>
</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "administrador";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtener datos del formulario
$Tarjeta = $_POST['Tarjeta'];
$Monto = $_POST['Monto'];
$Fecha_Registro = $_POST['Fecha_Registro'];

// Preparar la consulta SQL usando sentencia preparada
$sql = "INSERT INTO recargas (Tarjeta, Monto, Fecha_Registro) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $Tarjeta, $Monto, $Fecha_Registro);

// Ejecutar la consulta
if ($stmt->execute()) {
    echo "Recarga exitosa";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generador de Código QR</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url('https://revistamagazzine.com/wp-content/uploads/2023/07/MBA-Va-y-Ven-_magazzine-del-transporte-2-e1689206575467.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #000;
            padding: 15px 0;
            position: relative;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
        }
        header img {
            width: 150px;
            margin: 0 auto;
            display: block;
        }
        h1 {
            color: #ffd700;
            margin-top: 20px;
            margin-bottom: 20px;
            font-size: 2.5em;
            font-weight: 700;
        }
        .container {
            position: relative;
            display: inline-block;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            margin-top: 30px;
            max-width: 600px;
            width: 100%;
        }
        .qr-image {
            margin: 0 auto;
            border: 2px solid #ffd700;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            max-width: 100%;
            display: block;
        }
        .qr-code-text {
            margin-top: 10px;
            font-size: 1.2em;
            color: #ffd700;
        }
        .download-link {
            display: inline-block;
            padding: 10px 20px;
            color: #ffd700;
            border: 2px solid #ffd700;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            background-color: #000;
            transition: background-color 0.3s, transform 0.3s;
        }
        .download-link:hover {
            background-color: #ffd700;
            color: #000;
            transform: scale(1.05);
        }
        label {
            display: block;
            margin: 15px 0 5px;
            color: #ffd700;
            font-weight: 700;
        }
        input {
            width: calc(100% - 22px);
            padding: 12px;
            margin-bottom: 15px;
            border: 2px solid #ffd700;
            border-radius: 6px;
            background-color: #fff;
            color: #000;
            font-size: 1em;
        }
        button {
            padding: 12px 25px;
            background-color: #ffd700;
            color: #000;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 700;
            transition: background-color 0.3s, transform 0.3s;
        }
        button:hover {
            background-color: #e6c100;
            transform: scale(1.05);
        }
        .button-container {
            margin-top: 30px;
        }
        .button-container a {
            text-decoration: none;
        }
        .button-container button {
            background-color: #000;
            color: #ffd700;
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 700;
            transition: background-color 0.3s, transform 0.3s;
        }
        .button-container button:hover {
            background-color: #333;
            transform: scale(1.05);
        }
        .error-message {
            color: #ff0000;
            font-weight: bold;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <header>
        <!-- Logo eliminado -->
    </header>

    <h1>Generador de Código QR</h1>

    <div class="container">
        <?php
        // Conexión a la base de datos
        $host = 'localhost';
        $db = 'administrador';
        $user = 'root';
        $pass = '';

        $conn = new mysqli($host, $user, $pass, $db);

        if ($conn->connect_error) {
            echo "<p class='error-message'>Conexión fallida: " . $conn->connect_error . "</p>";
        } else {
            $qr_code = '';

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                if (isset($_POST['Correo'])) {
                    $correo = trim($_POST['Correo']);

                    // Preparar y ejecutar la consulta para verificar si el correo ya tiene un código QR
                    if ($stmt = $conn->prepare("SELECT * FROM usuarios WHERE Correo = ?")) {
                        $stmt->bind_param("s", $correo);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            $usuario = $result->fetch_assoc();

                            if (!empty($usuario['codigo_qr'])) {
                                // El usuario ya tiene un código QR
                                $qr_code = $usuario['codigo_qr'];
                            } else {
                                // Generar un código QR de 6 dígitos aleatorios único
                                do {
                                    $qr_code = mt_rand(100000, 999999);
                                    // Verificar si el código ya ha sido utilizado
                                    if ($check_stmt = $conn->prepare("SELECT * FROM usuarios WHERE codigo_qr = ?")) {
                                        $check_stmt->bind_param("i", $qr_code);
                                        $check_stmt->execute();
                                        $check_result = $check_stmt->get_result();
                                    } else {
                                        echo "<p class='error-message'>Error en la preparación de la consulta: " . $conn->error . "</p>";
                                        exit;
                                    }
                                } while ($check_result->num_rows > 0);

                                // Actualizar el código QR en la tabla de usuarios
                                if ($update_stmt = $conn->prepare("UPDATE usuarios SET codigo_qr = ? WHERE Correo = ?")) {
                                    $update_stmt->bind_param("is", $qr_code, $correo);
                                    $update_stmt->execute();
                                } else {
                                    echo "<p class='error-message'>Error en la preparación de la consulta: " . $conn->error . "</p>";
                                    exit;
                                }
                            }

                            // Generar el enlace del código QR usando un servicio de generación de QR
                            $qr_url = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' . urlencode($qr_code);

                            echo "<img src='$qr_url' alt='Código QR' class='qr-image'>";
                            echo "<div class='qr-code-text'>Código QR: $qr_code</div>";  
                            echo "<a href='$qr_url' download='codigo_qr.png' class='download-link'>Descargar QR</a>";
                        } else {
                            echo "<p class='error-message'>Usuario no encontrado.</p>";
                        }

                        $stmt->close();
                    } else {
                        echo "<p class='error-message'>Error en la preparación de la consulta: " . $conn->error . "</p>";
                    }
                } else {
                    echo "<p class='error-message'>No se recibió el correo electrónico.</p>";
                }
            }

            $conn->close();
        }
        ?>

        <form action="" method="post">
            <label for="Correo">Correo:</label>
            <input type="email" id="Correo" name="Correo" required>
            <button type="submit">Generar QR</button>
        </form>

        <div class="button-container">
            <a href="principal.php"><button>Cerrar</button></a>
        </div>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../KUTZBUZADMI/css/regist.css">
</head>
<body>
    <div class="container">
        <img src="../KUTZBUZADMI/img/logo.png" alt="Logo de la Empresa" class="logo">
        <h2>Registro</h2>
        <form action="registro.php" method="POST">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
            
            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" required>
            
            <label for="correo">Correo:</label>
            <input type="email" id="correo" name="correo" required>
            
            <label for="contraseña">Contraseña:</label>
            <input type="password" id="contraseña" name="contraseña" required>
            
            <label for="confirmar_contrasena">Confirmar Contraseña:</label>
            <input type="password" id="confirmar_contrasena" name="confirmar_contrasena" required>
            
            <button type="submit">Registrarse</button>
            <div class="botones">
                <button type="button" class="cerrar" onclick="cerrarVentana()">Cerrar</button>

                <script>
                  function cerrarVentana() {
                    window.location.href = 'principal.php';
                  }
                </script>
        </form>
    </div>
</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "administrador";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si se enviaron los datos por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener datos del formulario
    $nombre = isset($_POST['nombre']) ? $_POST['nombre'] : '';
    $apellido = isset($_POST['apellido']) ? $_POST['apellido'] : '';
    $correo = isset($_POST['correo']) ? $_POST['correo'] : '';
    $contraseña = isset($_POST['contraseña']) ? password_hash($_POST['contraseña'], PASSWORD_BCRYPT) : '';

    // Validar que todos los campos estén completos
    if (!empty($nombre) && !empty($apellido) && !empty($correo) && !empty($contraseña)) {
        // Insertar datos en la base de datos
        $sql = "INSERT INTO usuarios (nombre, apellido, correo, contraseña) VALUES ('$nombre', '$apellido', '$correo', '$contraseña')";
        
        if ($conn->query($sql) === TRUE) {
            echo "Registro exitoso";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Por favor complete todos los campos.";
    }
}

$conn->close();
?>

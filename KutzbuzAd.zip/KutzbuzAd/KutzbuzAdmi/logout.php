<?php
session_start();


$inactivity_limit = 300;

// Configuración de la cookie de sesión para que se destruya al cerrar el navegador
ini_set('session.cookie_lifetime', 0);

// Si la variable de última actividad está puesta y ha pasado el tiempo de inactividad
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $inactivity_limit) {
    // Destruir todas las variables de sesión
    $_SESSION = array();

    // Si se desea destruir la cookie de sesión, también
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Finalmente, destruir la sesión
    session_destroy();

    // Redirigir al usuario a la página de inicio o login
    header("Location: log.php");
    exit();
}

// Actualizar el tiempo de última actividad
$_SESSION['LAST_ACTIVITY'] = time();
<!DOCTYPE html>
<html>
<head>
    <title>Kutzbuz</title>
    <link rel="stylesheet" href="../KUTZBUZADMI/css/logemp.css">
   
</head>
<body>
    <h1>Login</h1>
    <form action="../KUTZBUZADMI/Verificar.php" method="post">
        <label for="Id_Empleado">ID de Empleado:</label>
        <input type="text" id="Id_Empleado" name="Id_Empleado" required><br><br>
        <label for="contraseña">Contraseña:</label>
        <input type="password" id="contraseña" name="contraseña" required><br><br>
        <button type="submit" name="verificar">Verificar</button>
        <button id="adminButton" type="button" onclick="window.location.href='administrador/Inicio.php'">Administración</button>
        <p><button onclick="redirectToLogout()">Cerrar sesión</button></p>
    </form>

    <!-- Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p id="modalMessage"></p>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById("myModal");
            const span = document.getElementsByClassName("close")[0];
            const modalMessage = document.getElementById("modalMessage");
            const adminButton = document.getElementById("adminButton");

            const urlParams = new URLSearchParams(window.location.search);
            const success = urlParams.get('success');
            const nombre = urlParams.get('nombre');
            const error = urlParams.get('error');

            if (success) {
                modalMessage.textContent = `Acceso exitoso. Bienvenido ${decodeURIComponent(nombre)}!`;
                modal.style.display = "block";
                adminButton.style.display = "block"; 
            } else if (error) {
                modalMessage.textContent = "ID de empleado o contraseña incorrectos.";
                modal.style.display = "block";
                adminButton.style.display = "none"; 
            }

            span.onclick = function() {
                modal.style.display = "none";
            }

            window.onclick = function(event) {
                if (event.target === modal) {
                    modal.style.display = "none";
                }
            }
        });
        
        function redirectToLogout() {
            window.location.href = 'log.php';
        }
    
    </script>
</body>
</html>

